# PharmaVerify — Complete Student Project

## Run
1. Extract this ZIP and install Python 3.10+.
2. Open a terminal in this folder.
3. Run `pip install -r requirements.txt`
4. Run `python app.py`
5. Open `http://127.0.0.1:5000`

## Admin login
Username: `admin`  
Password: `admin123`

## Pre-filled demo records
- `DEMO-PARA-001` — Paracetamol 500 mg
- `DEMO-CET-002` — Cetirizine 10 mg
- `DEMO-VITC-003` — Vitamin C 500 mg
- `DEMO-ORS-004` — ORS Sachet (expired status demo)
- `DEMO-ANTI-005` — Antacid Tablets (expiring-soon status demo)
- `DEMO-COUGH-006` — Cough Syrup

All names, manufacturers and batch numbers are fictional examples for a college demo, not verified commercial batches.

## How to use
1. Home page shows the six pre-filled demo records.
2. Click Verify Batch; try `DEMO-PARA-001`.
3. Try `DEMO-ORS-004` for expired status or `NOT-A-REAL-BATCH` for not found.
4. Login with the demo credentials.
5. Add Medicine to register a new fictional record with a unique batch number.
6. Dashboard lists all records and checks audit-chain integrity.
7. Audit Chain shows event payload, previous hash and current hash.

## How blockchain is used
The running website computes a SHA-256 hash fingerprint for each medicine record. Registration and verification actions are recorded in a local hash-linked audit chain: every event includes the previous event's hash. If an earlier event is modified, the integrity check should fail. This demonstrates the tamper-evident idea, but **the running app is not a decentralized blockchain**.

`blockchain/PharmaVerify.sol` is a sample smart contract that could store batch and record hashes on an EVM-compatible blockchain. It is included as source code only and is **not deployed or connected** to the Flask app. A real blockchain version needs contract deployment, contract address/ABI and Web3 integration.

A stored record does not independently prove that medicine is genuine. Real authenticity requires trusted manufacturer onboarding and verified supply-chain data. This is an academic prototype only.


## If the medicine list is empty
This ZIP includes a pre-filled `pharmaverify.db` file with six fictional records. Make sure it stays in the same folder as `app.py`. If you previously ran the project with an empty database, stop the server and replace that old `pharmaverify.db` with the database included in this ZIP. Back up your own records before replacing it.

## Barcode scanning feature
Use **Scan Barcode** in the top menu to scan a code with the camera or type a code. The customer page looks up registered barcode/batch values and shows the stored expiry status. Admin > Add Medicine has a Scan button to capture a barcode value while registering a record.

Camera scanning needs a supported browser and permission. Camera access is usually allowed on localhost or HTTPS. Demo barcode values such as `DEMO-BARCODE-001` are fictional and may not match real printed product barcodes. Normal retail barcodes often do not contain expiry dates; those details must be in a suitable GS1 code or linked to a trusted database. This app does not use a live medicine registry.


## Camera scanner fix
Scanner now shows clear error messages instead of silently failing. Allow camera for `http://127.0.0.1:5000`, enable Windows Settings > Privacy & security > Camera > Camera access and desktop-app access, close apps using the webcam, and refresh with Ctrl+Shift+R. Scanner library loading requires internet. Manual entry remains available.

## Camera fix v2
The scanner now detects available cameras and selects a compatible camera instead of forcing a rear-facing camera (which often fails on laptops). If no camera is detected, check Windows Device Manager > Cameras, close apps using the webcam, and try Chrome again. Camera scanning still requires the scanner library to load from the internet. Use manual code entry if no webcam is available.


## Camera display bug fix
The status message is now rendered in a separate status container instead of replacing the scanner/video container. Replacing the reader contents after camera start removes the video element, which can make it look like the camera never opened. The updated scanner keeps the video element intact.

## Customer accounts (new)
- Open `/customer/register` to create a customer account.
- Then sign in at `/customer/login`.
- Customer home contains only **Verify Batch** and **Scan Barcode**. Customer sessions are blocked from admin dashboard, adding medicine, audit chain, and demo-medicine API routes.
- Admin login remains `/admin/login` (demo credentials: `admin` / `admin123`).
- Login and registration pages now share a colorful purple-blue-teal design.
- This is a local academic demo. Demo medicine/batch/manufacturer/price records are fictional.
